
package br.com.novaroma.easycon.entities;

public abstract class Entity {
    
    public abstract String getId();
}
